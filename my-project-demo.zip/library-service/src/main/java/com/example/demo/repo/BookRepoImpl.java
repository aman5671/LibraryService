package com.example.demo.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import com.example.demo.model.Book;

@Repository
@Component(value = "bookRepo")
public interface BookRepoImpl extends JpaRepository<Book, Integer> {

	public List<Book> findByIsbn(String isbn);

	public List<Book> findByBookName(String name);

}