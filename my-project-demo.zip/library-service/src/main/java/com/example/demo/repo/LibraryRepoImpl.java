package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import com.example.demo.model.Library;

@Repository
@Component(value = "libraryRepo")
public interface LibraryRepoImpl extends JpaRepository<Library, Integer> {
	
}
