package com.example.demo.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class BookNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -1260315064685284145L;
	
	private String message;
	

}