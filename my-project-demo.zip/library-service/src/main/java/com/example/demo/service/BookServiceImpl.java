package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.exception.BookNotFoundException;
import com.example.demo.model.Book;
import com.example.demo.repo.BookRepoImpl;

@Service
@Component(value = "bookService")
public class BookServiceImpl{

	private BookRepoImpl bookRepo;
	
	@Autowired
	public BookServiceImpl(BookRepoImpl bookRepo) {
		this.bookRepo = bookRepo;
	}

	@Transactional
	public Book createBook(Book book) {
		bookRepo.save(book);
		Optional<Book> result = bookRepo.findById(book.getId());
		Book b1 = result.get();
		return b1;
	}

	@Transactional
	public List<Book> displayAllBooks() {
		return bookRepo.findAll();
	}
	
	@Transactional
	public Book findBookById(Integer id) {
		Optional<Book> result = bookRepo.findById(id);
		if (!result.isPresent()) {
			throw new BookNotFoundException("Book with the given id not found");
		}
		Book b1 = result.get();
		return b1;
	}
	
	@Transactional
	public Book findBookByIsbn(String isbn) {
		List<Book> result = bookRepo.findByIsbn(isbn);
		if (result.isEmpty()) {
			throw new BookNotFoundException("Book with the given ISBN not found");
		}
		Book b1 = result.get(0);
		return b1;
	}
	
	@Transactional
	public Book findBookByName(String name) {
		List<Book> result = bookRepo.findByBookName(name);
		if (result.isEmpty()) {
			throw new BookNotFoundException("Book with the given Name not found");
		}
		Book b1 = result.get(0);
		return b1;
	}

}