package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Library;
import com.example.demo.repo.LibraryRepoImpl;

@Service
@Component(value = "libraryService")
public class LibraryServiceImpl{
	private LibraryRepoImpl libraryRepo;

	@Autowired
	public LibraryServiceImpl(LibraryRepoImpl libraryRepo) {
		this.libraryRepo = libraryRepo;
	}

	@Transactional
	public Library createLibrary(Library library) {
		// TODO Auto-generated method stub
		libraryRepo.save(library);
		Optional<Library> result = libraryRepo.findById(library.getId());
		Library l1 = result.get();
		return l1;
	}

}
